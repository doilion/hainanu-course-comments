## Sci-hub

> 一个论文搜索平台，根据论文doi号可以获取论文全文

[https://sci-hub.ren/](https://sci-hub.ren/)

## 1lib

> 一个电子书分享网站，基本你可以在这里找到所有外文书籍的电子书

[https://1lib.us/](https://1lib.us/)

## 大学生必备资源库 - 公众号

> 包含各种课程及答案

[https://mp.weixin.qq.com/s?__biz=MzU2MzQzNzE3NQ==&mid=100002735&idx=1&sn=81decd6dda3a84a9d162f9370bce8bcb](https://mp.weixin.qq.com/s?__biz=MzU2MzQzNzE3NQ==&mid=100002735&idx=1&sn=81decd6dda3a84a9d162f9370bce8bcb)

## BIM软件安装管家 - 公众号

> 有多种常用软件（如PS、PR、C4D等）下载和破解

[https://mp.weixin.qq.com/s/Vvh3MRtl5aIeBf30O0Oc_g](https://mp.weixin.qq.com/s/Vvh3MRtl5aIeBf30O0Oc_g)

## 软件库 - 公众号

> 有多种常用软件（如Office等）下载和破解

[https://mp.weixin.qq.com/s/WIaG_Kx-qZqA74uux_CZxA](https://mp.weixin.qq.com/s/WIaG_Kx-qZqA74uux_CZxA)